import React, { Component } from "react";
import { Route } from "react-router-dom";
import { RouteComponentProps } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./components/Home";
import { FetchData } from "./components/FetchData";
import { Counter } from "./components/Counter";
import { AuthenticationComponent  } from "./components/AuthenticationComponent";
import { Login } from "./components/Login";

export const routes = (
    <Layout>
        //<Route path="/AuthenticationComponent" component={AuthenticationComponent} />
        <Route path="/Login" component={Login} />
        <Route exact path="/" component={Home} onEnter={requireLogin()}/>
    <Route path="/counter" component={Counter} />
        <Route path="/fetchdata" component={FetchData} onEnter={requireLogin()}/>
  </Layout>
);
function requireLogin() {
    console.log(10);
    
}
