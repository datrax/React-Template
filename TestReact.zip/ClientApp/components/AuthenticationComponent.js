import React, { Component } from "react";
import axios from 'axios';

export class AuthenticationComponent extends Component {
    render() {
        return null;
    }
    componentWillMount() {
        console.log('login contr');
        var history = this.props.history;
        var token = window.localStorage.getItem('token');
        if (!token) {
 
            history.push(`/Login`);
        }
       
        axios.get('/validateToken')
            .then(function (response) {
                console.log(response.status);
            })          
            .catch(function (error) {

                if (error.response.status == 401) {
                    history.push(`/Login`);
                }
            });

    }
}
